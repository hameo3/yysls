# 新建全局变量文件
collector_running = True
